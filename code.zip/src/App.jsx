import React from "react";
import SnakeLadder from "./components/SnakeLadder";

const App = () => {
  return <SnakeLadder />;
};

export default App;
